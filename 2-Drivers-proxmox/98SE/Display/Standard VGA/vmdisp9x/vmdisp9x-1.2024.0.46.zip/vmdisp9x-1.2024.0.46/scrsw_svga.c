#define SVGA
#include "scrsw.c"
