#define SVGA
#include "vxd_vdd.c"
