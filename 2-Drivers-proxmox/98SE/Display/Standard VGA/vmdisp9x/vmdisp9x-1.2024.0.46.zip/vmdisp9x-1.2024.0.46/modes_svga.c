#define SVGA
#include "modes.c"
