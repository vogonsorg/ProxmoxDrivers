#define SVGA
#include "vxd_main.c"
