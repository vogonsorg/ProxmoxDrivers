#define QEMU
#include "vxd_vdd.c"
