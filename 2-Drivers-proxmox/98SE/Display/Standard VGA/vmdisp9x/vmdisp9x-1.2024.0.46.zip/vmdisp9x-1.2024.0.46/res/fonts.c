/* Standard font resource for 96 DPI. */

#define OEM_FNT_HEIGHT   12
#define OEM_FNT_WIDTH    8

#include "fonttmpl.c"
