/* Font resource for 120 DPI. */

#define OEM_FNT_HEIGHT   10
#define OEM_FNT_WIDTH    20

#include "fonttmpl.c"
