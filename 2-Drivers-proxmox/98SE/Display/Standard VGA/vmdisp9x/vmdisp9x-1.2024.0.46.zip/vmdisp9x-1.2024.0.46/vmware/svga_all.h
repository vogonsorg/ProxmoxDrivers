#ifndef __SVGA_ALL_H__INCLUDED__
#define __SVGA_ALL_H__INCLUDED__

#pragma pack(push)
#pragma pack(1)
#include "svga.h"
#include "svga_reg.h"
#include "svga3d.h"
#include "svga3d_reg.h"
#include "svga3d_caps.h"
#include "svga3d_dx.h"
#pragma pack(pop)

#endif /* __SVGA_ALL_H__INCLUDED__ */
