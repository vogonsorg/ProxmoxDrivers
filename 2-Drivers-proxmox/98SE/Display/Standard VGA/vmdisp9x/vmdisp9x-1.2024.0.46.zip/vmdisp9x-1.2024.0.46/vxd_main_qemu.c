#define QEMU
#include "vxd_main.c"
