#define QEMU
#include "vxd_vbe.c"
