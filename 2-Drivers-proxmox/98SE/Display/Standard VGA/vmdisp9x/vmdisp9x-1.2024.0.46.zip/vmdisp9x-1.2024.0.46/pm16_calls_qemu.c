#define QEMU
#include "pm16_calls.c"
