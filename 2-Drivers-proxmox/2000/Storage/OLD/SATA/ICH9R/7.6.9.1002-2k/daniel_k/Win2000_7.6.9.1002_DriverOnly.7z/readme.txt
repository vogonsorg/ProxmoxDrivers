Patched by daniel_k

Please don't modify and redistribute publicly. Thanks.
